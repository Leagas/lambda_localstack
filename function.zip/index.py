import os
import re

AV_TARGET_FOLDER = "docstorage"
AV_FUNDPRESS_BUCKET = "local-anti-virus-asd"

print(os.environ)

def check_location(string):
    return re.search(AV_TARGET_FOLDER, string)

def handler(event, context):
	current_bucket = event['Records'][0]['s3']['bucket']['name']
	location = check_location(event['Records'][0]['s3']['object']['key']) if current_bucket == AV_FUNDPRESS_BUCKET else True

	if (current_bucket != AV_FUNDPRESS_BUCKET):
		print("\nWill scan file as normal because it's not our bucket...")

	if (current_bucket == AV_FUNDPRESS_BUCKET and bool(location) == True):
		print("\nWill scan file because file is in our target folder...\n")

	if (current_bucket == AV_FUNDPRESS_BUCKET and bool(location) == False):
		print("\nwill skip file, it was uploaded to our bucket but not the target folder...\n")

	if (bool(location) == False):
		return "Skipping file..."
	return "Scanning file..."
